%% B matrix and stress calculations
function [B,sigmav,Jac,J1,dN]=B_Matrix(zeta,eta,x,y,X,Y,lamda,mu)
dpN=[-(1-eta)/4 -(1-zeta)/4;(1-eta)/4 -(1+zeta)/4;(1+eta)/4 (1+zeta)/4;-(1+eta)/4 (1-zeta)/4];
Jac=[x(1) x(2) x(3) x(4);y(1) y(2) y(3) y(4)]*dpN;         % same as je matrix used in gaussian quadrature
dN=(dpN)*(inv(Jac));
for j=1:4
    B(:,((2*j)-1):2*j)=[dN(j,1) 0;0 dN(j,2);0 0;dN(j,2) dN(j,1)];
end
Fgr=inv([X(1) X(2) X(3) X(4);Y(1) Y(2) Y(3) Y(4)]*dN);   %dx/dX=F
J1=det(Fgr);     %small j
F=Fgr*Fgr';
sigmav=[(mu*F(1,1)/J1)+((lamda*log(J1)-mu)/J1);(mu*F(2,2)/J1)+((lamda*log(J1)-mu)/J1);((lamda*log(J1))/J1);(mu*F(1,2)/J1)];

