%% Body force calculations
function [Fext_body]=ext_for(be,p0,x,y,X,Y,lamda,mu,n)
Fext_body=0;
[w,zeta,eta] = Gauss_Legendre(n);
for i=1:n
for j=1:n
   [N1,N2,N3,N4,N] = Sf(zeta(i),eta(j));
   [B,sigmav,Jac,J1,dN]=B_Matrix(zeta(i),eta(j),x,y,X,Y,lamda,mu);
   p=p0/det(J1);
Fext=(p*(N)'*N*be)*det(Jac);
Fext_body=Fext_body+(Fext)*w(i)*w(j);
end
end