1)Change the directory in matlab to current folder

2)Open the .m files in the folder inside matlab(there are eigth .m files)

3)Run the main.m file 

4)Rest files are just function files

5)The code is loaded with 3 examples

6)To see limit point run example 2(use arc length approaches to see limit point)

7)To see general quadrilateral elements(other then rectangle) run example 3

8)In example 3 you have to zoom in to see the applied boundary conditions and forces, 
in rest of the examples boundary conditions and forces are visible clearly(in the intial configuration plot)


