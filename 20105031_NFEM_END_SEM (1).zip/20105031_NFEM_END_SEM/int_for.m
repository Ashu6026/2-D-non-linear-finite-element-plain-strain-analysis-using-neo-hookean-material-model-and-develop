%% Internal force calculations
function [Fint_body]=int_for(x,y,X,Y,lamda,mu,n)
Fint_body=0;
[w,zeta,eta]=Gauss_Legendre(n);
for i=1:n
for j=1:n
    [B,sigmav,Jac,J1,dN]=B_Matrix(zeta(i),eta(j),x,y,X,Y,lamda,mu);
Fint=B'*sigmav*det(Jac);
Fint_body=Fint_body+(Fint)*w(i)*w(j);
end
end