%% Shape functions used
function[N1,N2,N3,N4,N] = Sf(zeta,eta) 

N1 = (1-zeta)*(1-eta)/4;
N2 = (1+zeta)*(1-eta)/4;
N3 = (1+zeta)*(1+eta)/4;
N4 = (1-zeta)*(1+eta)/4;

N=[N1*eye(2,2) N2*eye(2,2) N3*eye(2,2) N4*eye(2,2)];

end