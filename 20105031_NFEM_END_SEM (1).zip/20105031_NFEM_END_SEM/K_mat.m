%% Stiffness matrix calculations
function [K,Kmat,Kgeof]=K_mat(x,y,X,Y,lamda,mu,n)
Kmat=0;
Ip4=[1 1 1 0;1 1 1 0;1 1 1 0;0 0 0 0];
Is4=[2 0 0 0;0 2 0 0;0 0 2 0;0 0 0 1];
D=lamda*Ip4+mu*Is4;
[w,zeta,eta]=Gauss_Legendre(n);
for i=1:n
for j=1:n
    [B,sigmav,Jac,J1]=B_Matrix(zeta(i),eta(j),x,y,X,Y,lamda,mu);
    cv=(D/J1)-lamda*log(J1)*Is4/J1;
K_mat=B'*cv*B*det(Jac);
Kmat=Kmat+K_mat*w(i)*w(j);
end
end


Kgeof=zeros(8,8);
for k=1:4
    for m=1:4
Kgeo=0;
for i=1:n
for j=1:n
    [B,sigmav,Jac,J1,dN]=B_Matrix(zeta(i),eta(j),x,y,X,Y,lamda,mu);
    sigma1=[sigmav(1,1) sigmav(4,1);sigmav(4,1) sigmav(2,1)];
    K_geo=dN(k,:)*sigma1*(dN(m,:))'*det(Jac);
    Kgeo=Kgeo+K_geo*w(i)*w(j);
end
end
Kgeo1=eye(2,2)*Kgeo;
Kgeof(2*k-1:2*k,2*m-1:2*m)=Kgeo1;
    end    
end

K=Kmat+Kgeof;

