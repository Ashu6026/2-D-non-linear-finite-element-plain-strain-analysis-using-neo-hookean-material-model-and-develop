%Name:Ashu Jaglan
%Roll no:20105031
%NFEM END SEM SUBMISSION
%%
clear all
clc
%% Material Properties

E=100;                          %Young's Modulus
v=0.3;                          %Poison's ratio
mu=E/(2*(1+v));                 %Lame's constant
lamda=(2*mu*v)/(1-(2*v));       %Lame's constant
p0=1;                           %Intial density of material
n=2;                            %Order of gaussian integration
%% Input from user

disp('Example 1: Cantilever Beam')
disp('Example 2: Curved beam')
disp('Example 3: Plate with circular hole')
disp('--------------------------------------------------------------------')
exmp=input('Enter the example number you wish to run: ');
disp('--------------------------------------------------------------------')

disp('Iteration Technique 1: Newton Raphson')
disp('Iteration Technique 2: Arc-Length-Ricks Implementation')
disp('Iteration Technique 3: Arc-Lengt-Crisfield Implementation')

if exmp==2
    disp('****Note: To see the limit point in curved beam use Arc length Techniques****')
end
disp('--------------------------------------------------------------------')
NR_ARC=input('Iteration technique you wish to use: ');
disp('--------------------------------------------------------------------')
disp('Analysis Is running: PLEASE WAIT')
disp('--------------------------------------------------------------------')

%% Plate with circular hole

if exmp == 3 
    
load nodesplate.dat                        %Loading nodes data
load elemplate.dat                         %Loading elemntal connectivity data
nodes=nodesplate;
elem=elemplate;
Ne=size(elem,1);                           %Total number of elements
dispbc = [1 12 1;2 12 2;3 31 1;4 31 2;5 32 1;6 32 2;7 33 1;8 33 2;9 34 1;10 34 2;11 10 1;12 10 2];      %Boundary conditions [serial number;node number;d.o.f to be fixed]
forces=[1 22 1 100;2 22 2 -50];                                                                         %[serial number;node number;d.o.f;force magnitude]
disp_dof=22;                                                                                            %D.O.F to be plotted

end
%% Curved beam

if exmp == 2
    
load nodescurved.dat                     %Loading nodes data
nodes=nodescurved;
nnx=41;                                  %number of nodes in x-direction
nny=3;                                   %number of nodes in y-direction
Ne = (nnx-1)*(nny-1);                    %Total number of elements

elem = zeros(Ne,5);                      %elem: element connectivity
for i = 1:(nnx -1)
    for j = 1:(nny -1)
        eno = i +(nnx-1)*(j-1);
        ino = i+nnx*(j-1);
        elem(eno,:) = [eno ino ino+1 ino+nnx+1 ino+nnx];
    end
end
dispbc = [1 1 1; 2 1 2; 3 (size(nodes,1)-nnx+1) 1;4 (size(nodes,1)-nnx+1) 2;5 nnx 1;6 nnx 2;7 size(nodes,1) 1;8 size(nodes,1) 2];  %Boundary conditions [serial number;node number;d.o.f to be fixed]
for i = 1:(nny-2)
    dispbc=[dispbc;(7+i) (nnx)*i+1 1;(8+i) (nnx)*i+1 2;(9+i) nnx*(i+1) 1;(10+i) nnx*(i+1) 2];
end
forces = [1 (size(nodes,1)-((nnx-rem(nnx,2))/2)) 2 -5.5;];           %[serial number;node number;d.o.f;force magnitude]
disp_dof=(size(nodes,1)-((nnx-rem(nnx,2))/2))*2;                   %D.O.F to be plotted

end
%% Cantilever beam

if exmp == 1
        
Lx = 5; Ly = 1;                          % Lx: Length of domain along x; Ly: Length of domain along y
dx = 0.25; dy =0.25;                     % dx: Element length along x; dy: Element length along y
nnx = Lx/dx + 1; nny = Ly/dy + 1;        % nnx: No. of nodes along x; nny: No. of nodes along y
Ne = (nnx-1)*(nny-1);                    % Ne: Total no. of elements
%nodes = [node # , X location , Y location]  
nodes = zeros(nnx*nny,3);
for j = 1:nny
    for i = 1:nnx
        nodes(i + (j-1)*nnx,:) = [i+(j-1)*nnx (i-1)*dx (j-1)*dy];
    end
end
%elem: element connectivity
elem = zeros(Ne,5);
for i = 1:(nnx -1)
    for j = 1:(nny -1)
        eno = i +(nnx-1)*(j-1);
        ino = i+nnx*(j-1);
        elem(eno,:) = [eno ino ino+1 ino+nnx+1 ino+nnx];
    end
end
dispbc = [1 1 1; 2 1 2;3 (size(nodes,1)-nnx+1) 1;4 (size(nodes,1)-nnx+1) 2];       %Boundary conditions [serial number;node number;d.o.f to be fixed]
for i = 1:(nny-2)
     dispbc=[dispbc;(4+i) (nnx)*i+1 1;(5+i) (nnx)*i+1 2;];
end

forces = [1 (size(nodes,1)) 2 1;];                  %[serial number;node number;d.o.f;force magnitude]
disp_dof=(size(nodes,1))*2;                         %D.O.F to be plotted

end
%% Body force vector and traction vector at nodes in deformed configuration

be=zeros(2*size(nodes,1),1);                       %body force vector in deformed configuration-default kept at zero
te=zeros(2*size(nodes,1),1);                       %traction vector in deformed configuration-default kept at zero

%% forces: External Forces
F0 = zeros(2*size(nodes,1),1);                     %Force vector giving information of concentrated force on each node
% Generating external force matrix
for i = 1:size(forces,1)
    F0(2*(forces(i,2)-1) + forces(i,3),1) = forces(i,4);
end
%% Applying B.C.
C = elem(:,[2 3 4 5]);    % C: Connectivity
NX = nodes(:,[2 3]);      % NX: Node Location

fdof = zeros(1,size(dispbc,1));
for i = 1:size(dispbc,1)
    fdof(1,i) = 2*(dispbc(i,2)-1) + dispbc(i,3);        % fdof : fixed degree of freedom
end
Freedof = setdiff(1:size(NX,1)*size(NX,2),fdof);        % freedof : Free degrees of fredom


%% MOVIE generation and graph plotting...
OBJ1 = VideoWriter('Movie_1_end_sem_Body_deformation','MPEG-4');
OBJ2 = VideoWriter('Movie_2_end_sem_load_deflection','MPEG-4');
open(OBJ1); open(OBJ2);

%% Shape functions and its derivatives

syms zeta eta
N1 = (1-zeta)*(1-eta)/4;
N2 = (1+zeta)*(1-eta)/4;
N3 = (1+zeta)*(1+eta)/4;
N4 = (1-zeta)*(1+eta)/4;

syms N(zeta,eta)
N(zeta,eta)=[N1*eye(2,2) N2*eye(2,2) N3*eye(2,2) N4*eye(2,2)];

syms N1(zeta,eta)
N1(zeta,eta)=N.'*N;
dpN=[-(1-eta)/4 -(1-zeta)/4;(1-eta)/4 -(1+zeta)/4;(1+eta)/4 (1+zeta)/4;-(1+eta)/4 (1-zeta)/4];

%% Iterations

v=zeros(2*size(nodes,1),1);    % intial displacement set to zero

if NR_ARC==1 % NEWTON RAHPSON'S IMPLEMENTATION
    TOL = 1e-20;               % tolerance on iterative displacements
    v_p  = v;                  % set initial displacements to zero...
    del_lambda = 0.025;          % force increments, leveling parameter
    lambda = 0;                % net leveling parameter
    k_inc = 1;                 % total number of increments
    for lambda = del_lambda:del_lambda:1   % loop for force increments
        fprintf('increment: %3d,  net leveling parameter: %3.2f \n',k_inc,lambda);
        k_iter = 1;            % number of NR iterations
        Delta_v = 0*v_p;
        converge = 12345;
        while converge > TOL   % NR iterations
            
            delta_v = 0*v_p;
            [Fext_body,Fext_traction,x,y,X,Y]=updated_cordinates(nodes,C,NX,v_p+Delta_v,be,te,lamda,mu,n,p0);
            F=Fext_traction+Fext_body+F0;
            [g,K,Fint_body] = two_flex_trusses_NFEM_smart(nodes,C,NX,lamda,mu,v_p+Delta_v,lambda*F,n);    %Extracting force residual and stiffness matrix
            delta_v(Freedof) = -inv(K(Freedof,Freedof))*g(Freedof);     % iterative correction in displacements
            converge = (abs(g'*delta_v));                               % convergence measure
            Delta_v = Delta_v + delta_v;                                % updated orientations (ref. horizontal)
            fprintf('iter: %3d, converge: %3.8f \n',k_iter,converge);   
            k_iter = k_iter+1;                                          
            
        end
        
        plot_two_flex_trusses_NFEM(v_p,C,NX,dispbc,forces,Freedof,1); pause(1e-6)     %Calling the plotting function          
        v_p = v_p + Delta_v;
        figure(1); currFrame1 = getframe(gcf);   writeVideo(OBJ1,currFrame1); pause(1e-6);
        vstore(k_inc) = v_p(disp_dof);                                   % vertical displacement @ node 3, say
        Fstore(k_inc) = lambda;
        figure(2);
        plot(vstore,Fstore,'b.','linewidth',2); hold on 
        plot(vstore,Fstore,'go','MarkerSize',14);
         title('Load v/s Displacement Curve');
         xlabel('v(displacement of node on which force is applied) ','FontSize',16); ylabel(' \lambda (Fraction of input force)','FontSize',16);
         xlim auto;
         ylim auto;
         
         currFrame2 = getframe(gcf);   writeVideo(OBJ2,currFrame2); pause(1e-6);
         k_inc = k_inc + 1;
        fprintf('----------------------------------------------------\n');
    end
     close(OBJ1); close(OBJ2);
     disp('Analysis is complete, Thank you for your patience');
end


if NR_ARC==2 % ARC LENGTH --- RIK'S IMPLEMENTATION
  TOL = 1e-20;                % tolerance on iterative displacements
    psi = 1;        % 0 for cylindrical, 1 for spherical
    lambda = 0;   	% initial force increment, and change
    Del_lam = 0.1;  % force increment
    del_l = 0.2;      % arc length for example 3    
    k_lam = 1;      % total number of lambda increments
    v = zeros(2*size(nodes,1),1);    % overall displacements...
    Delta_v = zeros(2*size(nodes,1),1);  % change in displacements
        while lambda <= 1
        k_iter = 0;
        v_p = v;                % previous displacements...
        lambda_p = lambda;      % previous load increment
        converge = 12345678;    % dummy convergence value
        while converge > TOL,   % arc length iterations commence
            
            [Fext_body,Fext_traction,x,y,X,Y]=updated_cordinates(nodes,C,NX,v_p+Delta_v,be,te,lamda,mu,n,p0);
            F=Fext_traction+Fext_body+F0;
            [g,K,Fint_body] = two_flex_trusses_NFEM_smart(nodes,C,NX,lamda,mu,v_p+Delta_v,(lambda_p+Del_lam)*F,n);
            
            
            % DO APPLY Boundary Conditions
            Kt_free = K(Freedof,Freedof); 
            Fo_free = F(Freedof);
            Delta_v_free = Delta_v(Freedof);
            g_free = g(Freedof);
            
            % the update matrix
            AA = [Kt_free  -Fo_free;  2*Delta_v_free' 2*psi^2*Fo_free'*Fo_free*Del_lam];
            BB = [-g_free; del_l^2-Delta_v_free'*Delta_v_free-psi^2*Fo_free'*Fo_free*Del_lam^2];
            tmp = inv(AA)*BB;
            
            delta_v = 0*v;  % initialization (though not needed)
            delta_v(Freedof) = tmp([1:size(tmp,1)-1],1);
            del_lambda = tmp(size(tmp,1),1);

            % updates in Delta_lam, and Delta_TH
            Del_lam = Del_lam + del_lambda; % force increment update
            Delta_v = Delta_v + delta_v;
            converge = (abs(g'*delta_v));
            k_iter = k_iter + 1;
            fprintf('iter: %3d, del_lam: %3.4f, conv: %3.4e\n',k_iter,del_lambda,converge);

        end
        % overall updates --- lambda and generalized dofs
       lambda = lambda_p + Del_lam;
       v = v_p + Delta_v;
        plot_two_flex_trusses_NFEM(v_p,C,NX,dispbc,forces,Freedof,1); pause(1e-6)
       
       figure(1); currFrame1 = getframe(gcf);   writeVideo(OBJ1,currFrame1); pause(1e-6);
        vstore(k_iter) = v(disp_dof); % vertical displacement @ hinge 2, say
        Fstore(k_iter) = lambda;
        figure(2);
        plot(vstore,Fstore,'r.','linewidth',2); hold on
        plot(vstore,Fstore,'bs','MarkerSize',14);
        title('Load v/s Displacement Curve');
        xlabel('v(displacement of node on which force is applied) ','FontSize',16); ylabel(' \lambda (Fraction of input force)','FontSize',16);
        xlim auto;
        ylim auto;
        grid on
        currFrame2 = getframe(gcf);   writeVideo(OBJ2,currFrame2); pause(1e-6);
        k_lam = k_lam + 1;
        fprintf('----------------------------------------------------\n');
        
         end
    close(OBJ1); close(OBJ2);
    disp('Analysis is complete, Thank you for your patience');
 end


 if NR_ARC==3  % ARC LENGTH --- CRISFIELD'S IMPLEMENTATION
    TOL = 1e-20;                % tolerance on iterative displacements
    psi = 1;        % 0 for cylindrical, 1 for spherical
    lambda = 0;   	% initial force increment, and change
    Del_lam = 0.01; % force increment
    del_l = 0.5;
    k_lam = 1;      % total number of lambda increments
    v = zeros(2*size(nodes,1),1);        % overall displacements...
    Delta_v = zeros(2*size(nodes,1),1);  % change in displacements
    while lambda <= 1
        k_iter = 0;
        v_p = v;                % previous displacements...
        lambda_p = lambda;      % previous load increment
        converge = 123456;      % dummy convergence value
        while converge > TOL,   % arc length iterations commence
           
            [Fext_body,Fext_traction,x,y,X,Y]=updated_cordinates(nodes,C,NX,v_p+Delta_v,be,te,lamda,mu,n,p0);
            F=Fext_traction+Fext_body+F0;
            [g,K,Fint_body] = two_flex_trusses_NFEM_smart(nodes,C,NX,lamda,mu,v_p+Delta_v,(lambda_p + Del_lam)*F,n);
           
           
            % DO APPLY Boundary Conditions
            Kt_free = K(Freedof,Freedof); 
            Fo_free = F(Freedof);
            Delta_v_free = Delta_v(Freedof);
            g_free = g(Freedof);
          
            par_g_par_lam = -Fo_free;
            
            % Inverting a matrix twice below --- Costly? 
            delta_v1 = 0*Delta_v;  % initialization (though not needed)
            delta_v1(Freedof) = -inv(Kt_free)*g_free;
            delta_v2 = 0*Delta_v;  % initialization (though not needed)
            delta_v2(Freedof) = -inv(Kt_free)*par_g_par_lam;
            
            % coefficients of the quadratic in del_lambda
            C2 = delta_v2'*delta_v2 + psi^2*F'*F;
            C1 = 2*(Delta_v + delta_v1)'*delta_v2 + 2*psi^2*Del_lam*F'*F;
            C0 = (Delta_v + delta_v1)'*(Delta_v + delta_v1) + psi^2*Del_lam^2*F'*F - del_l^2;
            
            % coefficients used to determine the angle between Delta_vn and Delta_v;
            C3 = Delta_v'*delta_v1 + Delta_v'*Delta_v + Del_lam*Del_lam;
            C4 = Delta_v'*delta_v2 + Del_lam;
            
            DISCRIM = C1^2 - 4*C0*C2;
            if DISCRIM > 0
                del_lam1 = -C1/2/C2 + sqrt(DISCRIM)/2/C2;
                del_lam2 = -C1/2/C2 - sqrt(DISCRIM)/2/C2;
                
                if (C3 + C4*del_lam2) > (C3 + C4*del_lam1),  del_lam = del_lam2;
                else,                                        del_lam = del_lam1;
                end
                
                Del_lam = Del_lam + del_lam; % force increment update
                % displacement update -- current displacement
                Delta_v = Delta_v + delta_v1 + del_lam*delta_v2;
                converge = (abs(g'*(delta_v1 + del_lam*delta_v2) ) );
                
                k_iter = k_iter + 1;
                fprintf('iter: %3d, del_lam: %3.4f, conv: %3.4e\n',k_iter,del_lam,converge);
                                            
            else
                fprintf('Imaginary ROOTS ---- '); pause; break;
            end
        end
        
        % overall updates --- lambda and generalized dofs
        lambda = lambda_p + Del_lam;
        v = v_p + Delta_v;
        plot_two_flex_trusses_NFEM(v_p,C,NX,dispbc,forces,Freedof,1); pause(1e-6);
        figure(1); currFrame1 = getframe(gcf);   writeVideo(OBJ1,currFrame1); pause(1e-6);
        vstore(k_iter) = v(disp_dof); % vertical displacement @ hinge 2, say
        Fstore(k_iter) = lambda;
        figure(2);
        plot(vstore,Fstore,'k.','linewidth',2); hold on
        plot(vstore,Fstore,'kh','MarkerSize',14);
        title('Load v/s Displacement Curve');
        xlabel('v(displacement of node on which force is applied) ','FontSize',16); ylabel(' \lambda (Fraction of input force)','FontSize',16);
        xlim auto;
        ylim auto;
        grid on
        currFrame2 = getframe(gcf);   writeVideo(OBJ2,currFrame2); pause(1e-6);
        k_lam = k_lam + 1;
        fprintf('----------------------------------------------------\n');
    end
    close(OBJ1); close(OBJ2);
 disp('Analysis is complete, Thank you for your patience');
 end 
   % % % % % %___________________
   

%% Plotting the beam configurations

function []=plot_two_flex_trusses_NFEM(v,C,NX,dispbc,forces,Freedof,figg) 
figure(figg); clf; hold on;

%% Plotting initial domian and mesh 
figure(1); 
title('Deformed configuration')
patch('Faces',C,'Vertices', NX,'Facecolor','g');
axis equal

%% Plotting initial domian and mesh 
figure(3);
title('Intial Configuration')
patch('Faces',C,'Vertices', NX,'Facecolor','g');
axis equal

%% Plotting fixed boundary conditions
fbcx = [0 0; -0.05 -0.025; -0.05 0.025];    % fbcx : Parameters for triangular shape to be plotted
fbcy = [fbcx(:,2) fbcx(:,1)];               % fbcy : Parameters for triangular shape to be plotted

dispID = zeros(1,size(dispbc,1));
for i = 1:size(dispbc,1)
    fix_node = dispbc(i,2);                 % fix_node : Node number of fixed node
    fix_dof = dispbc(i,3);                  % fix_dof : Degree of freedom that is fixed
    dispID(i) = 3*fix_node-3+fix_dof;
    
    if fix_dof==1
        vx = fbcx(:,1) + NX(fix_node,1)*ones(3,1);
        vy = fbcx(:,2) + NX(fix_node,2)*ones(3,1);
        patch(vx',vy','r');
        hold on
    end
    if fix_dof==2
        vx = fbcy(:,1) + NX(fix_node,1)*ones(3,1);
        vy = fbcy(:,2) + NX(fix_node,2)*ones(3,1);
        patch(vx',vy','g');
        hold on
    end
    
end

%% Plotting surface tractions

for i=1:size(forces,1)
    fext_node = forces(i,2);
    fext_dof = forces(i,3);
    fext_val = forces(i,4);
    fext_id = 3*(fext_node - 1) + fext_dof;
%     F(fext_id,1) = fext_val;
    
    if fext_dof==1
        quiver(NX(fext_node,1),NX(fext_node,2),0.25*fext_val/max(abs(forces(:,4))),0,'linewidth',2,'color','k')
    end
    if fext_dof==2
        quiver(NX(fext_node,1),NX(fext_node,2),0,0.25*fext_val/max(abs(forces(:,4))),'linewidth',2,'color','k')
    end
    hold on
end

%% Post-Processing (Plotting final domain)
U = zeros(size(NX,1)*size(NX,2),1);     % U : Displacement vector for all d.o.fs
U(Freedof,1) = v(Freedof);

pu = zeros(size(NX,1),2);
for i = 1:size(NX,1)
    pu(i,1) = U(2*(i-1)+1,1);
    pu(i,2) = U(2*(i-1)+2,1);
end
figure(1); patch('Faces',C,'Vertices', NX+pu,'Facecolor','r');
alpha(0.3)
axis equal
%%
end

%% Stifness matrix and force residual calculations

function [g,Kt_G,Fint_A] = two_flex_trusses_NFEM_smart(nodes,C,NX,lamda,mu,u,Fo,n)

Kt_G = zeros(size(NX,2)*size(NX,1));
Fint_A=zeros(2*size(nodes,1),1);

for k = 1:size(C,1)
%% Extracting original coordinates
a=C(k,1);          % 1st node of element i
b=C(k,2);          % 2nd node of element i
c=C(k,3);          % 3rd node of element i
d=C(k,4);          % 4th node of element i
%extrating corrdinates of nodes of an element
X1 = nodes(a,2);  Y1 = nodes(a,3);                  
X2 = nodes(b,2);  Y2 = nodes(b,3);
X3 = nodes(c,2);  Y3 = nodes(c,3);
X4 = nodes(d,2);  Y4 = nodes(d,3);


%% Extracting displacements
u1 = u(2*a-1,1);    v1 = u(2*a,1);
u2 = u(2*b-1,1);    v2 = u(2*b,1); 
u3 = u(2*c-1,1);    v3 = u(2*c,1);
u4 = u(2*d-1,1);    v4 = u(2*d,1);

%% New coordinates
x1=X1+u1;   y1=Y1+v1;
x2=X2+u2;   y2=Y2+v2;  
x3=X3+u3;   y3=Y3+v3;
x4=X4+u4;   y4=Y4+v4;

X=[X1;X2;X3;X4];
Y=[Y1;Y2;Y3;Y4];
x=[x1;x2;x3;x4];
y=[y1;y2;y3;y4];
[Fint_body]=int_for(x,y,X,Y,lamda,mu,n);         %calling the int_for function to get the internal forces on the element
[K,Kmat,Kgeof]=K_mat(x,y,X,Y,lamda,mu,n);        %calling the K_mat function to get the stiffness matrix on the element


%Assembly of stiffness matrix 
    for i = 1:size(K,1)
        for j = 1:size(K,2)
            ii= rem(i,2); jj = rem(j,2);
            lci = (i + ii)/2 ; lcj = (j + jj)/2;
            if ii == 0, ii=2; end
            if jj == 0, jj=2; end
            Kt_G(2*(C(k,lci)-1) + ii,2*(C(k,lcj)-1) + jj) = ...
                Kt_G(2*(C(k,lci)-1) + ii,2*(C(k,lcj)-1) + jj) + K(i,j);
        end
    end   
    
 %Assembly of internal force matrix 
    for i = 1:size(Fint_body,1)
        ii= rem(i,2);
        lci = (i + ii)/2;
        if ii == 0, ii=2; end
        Fint_A(2*(C(k,lci)-1) + ii,1) = ...
                Fint_A(2*(C(k,lci)-1) + ii,1) + Fint_body(i,1);
            
    end
end

%Force residual
g=Fint_A-Fo;
end


%% Function to calculate updated coordinates

function [Fext_bodyA,Fext_tractionA,x,y,X,Y]=updated_cordinates(nodes,C,NX,u,be,te,lamda,mu,n,p0)

Fext_bodyA=zeros(2*size(nodes,1),1);
Fext_tractionA=zeros(2*size(nodes,1),1);

for k = 1:size(C,1)
%% Extracting original coordinates
a=C(k,1);          % 1st node of element i
b=C(k,2);          % 2nd node of element i
c=C(k,3);          % 3rd node of element i
d=C(k,4);          % 4th node of element i
X1 = nodes(a,2);  Y1 = nodes(a,3);
X2 = nodes(b,2);  Y2 = nodes(b,3);
X3 = nodes(c,2);  Y3 = nodes(c,3);
X4 = nodes(d,2);  Y4 = nodes(d,3);


%% Extracting displacements
u1 = u(2*a-1,1);    v1 = u(2*a,1);
u2 = u(2*b-1,1);    v2 = u(2*b,1); 
u3 = u(2*c-1,1);    v3 = u(2*c,1);
u4 = u(2*d-1,1);    v4 = u(2*d,1);

%% New coordinates
x1=X1+u1;   y1=Y1+v1;
x2=X2+u2;   y2=Y2+v2;  
x3=X3+u3;   y3=Y3+v3;
x4=X4+u4;   y4=Y4+v4;

X=[X1;X2;X3;X4];
Y=[Y1;Y2;Y3;Y4];
x=[x1;x2;x3;x4];
y=[y1;y2;y3;y4];

% Body Force calculation
be1=[be(2*C(k,1)-1:2*C(k,1),1);be(2*C(k,2)-1:2*C(k,2),1);be(2*C(k,3)-1:2*C(k,3),1);be(2*C(k,4)-1:2*C(k,4),1)];
[Fext_body]=ext_for(be1,p0,x,y,X,Y,lamda,mu,n);
%Assembly of body forces 
    for i = 1:size(Fext_body,1)
        ii= rem(i,2);
        lci = (i + ii)/2;
        if ii == 0, ii=2; end
        Fext_bodyA(2*(C(k,lci)-1) + ii,1) = ...
                Fext_bodyA(2*(C(k,lci)-1) + ii,1) + Fext_body(i,1);
    end

% External traction calculation
%Uncomment below lines if you wish to use external traction-The analysis will take longer time to run

%  te1=[te(2*C(k,1)-1:2*C(k,1),1);te(2*C(k,2)-1:2*C(k,2),1);te(2*C(k,3)-1:2*C(k,3),1);te(2*C(k,4)-1:2*C(k,4),1)];
%  [Fext_traction]=traction(x,y,X,Y,te1,n,lamda,mu);
%  %Assembly of external traction forces   
%     for i = 1:size(Fext_traction,1)
%         ii= rem(i,2);
%         lci = (i + ii)/2;
%         if ii == 0, ii=2; end
%         Fext_tractionA(2*(C(k,lci)-1) + ii,1) = ...
%                 Fext_tractionA(2*(C(k,lci)-1) + ii,1) + Fext_traction(i,1);
%     end

end

end