%% Numerical integration schemes
function [w,zeta,eta] = Gauss_Legendre(ng)

if ng == 1
    w(1) = 2; zeta(1) = 0;eta(1) = 0;
end

if ng == 2
    w(1) = 1; w(2) = 1;
    zeta(1) = 0.577350269189626; zeta(2) = -0.577350269189626; 
    eta(1) = 0.577350269189626; eta(2) = -0.577350269189626; 
end

if ng == 3
    w(1) = 5/9; w(2) = 8/9; w(3) = 5/9;
    zeta(1) = sqrt(3/5); zeta(2) = 0; zeta(3) = -sqrt(3/5); 
    eta(1) = sqrt(3/5); eta(2) = 0; eta(3) = -sqrt(3/5);
end
end