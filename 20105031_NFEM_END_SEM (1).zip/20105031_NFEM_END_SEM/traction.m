%% External force vector at nodes calculation from applied traction vector
function [Fext_traction]=traction(x,y,X,Y,te,n,lamda,mu)
x1=x(1);
x2=x(2);
x3=x(3);
x4=x(4);
y1=y(1);
y2=y(2);
y3=y(3);
y4=y(4);


[w,zeta,eta] = Gauss_Legendre(n);
Fext_traction1=0;
Fext_traction2=0;
Fext_traction3=0;
Fext_traction4=0;

for i=1:n
    
etta=-1;

    [N1,N2,N3,N4,N] = Sf(zeta(i),etta) ;

    Fext1=N.'*N*((x1*(etta/4 - 1/4) - x2*(etta/4 - 1/4) + x3*(etta/4 + 1/4) - x4*(etta/4 + 1/4))^2 + (y1*(etta/4 - 1/4) - y2*(etta/4 - 1/4) + y3*(etta/4 + 1/4) - y4*(etta/4 + 1/4))^2)^(1/2) ;
    Fext_traction1=Fext_traction1+(Fext1)*w(i);



zeeta=1;
    [N1,N2,N3,N4,N] = Sf(zeeta,eta(i)) ;
    %[N1,N2,N3,N4,N] = Sf(zeeta,eta(i));
    Fext2=N.'*N*((x1*(zeeta/4 - 1/4) - x2*(zeeta/4 + 1/4) + x3*(zeeta/4 + 1/4) - x4*(zeeta/4 - 1/4))^2 + (y1*(zeeta/4 - 1/4) - y2*(zeeta/4 + 1/4) + y3*(zeeta/4 + 1/4) - y4*(zeeta/4 - 1/4))^2)^(1/2) ;
    Fext_traction2=Fext_traction2+(Fext2)*w(i);



etta=1;
    [N1,N2,N3,N4,N] = Sf(zeta(i),etta);
    Fext3=N.'*N*((x1*(etta/4 - 1/4) - x2*(etta/4 - 1/4) + x3*(etta/4 + 1/4) - x4*(etta/4 + 1/4))^2 + (y1*(etta/4 - 1/4) - y2*(etta/4 - 1/4) + y3*(etta/4 + 1/4) - y4*(etta/4 + 1/4))^2)^(1/2) ;
    Fext_traction3=Fext_traction3+(Fext3)*w(i);



zeeta=-1;
    [N1,N2,N3,N4,N] = Sf(zeeta,eta(i));
    Fext4=N.'*N*((x1*(zeeta/4 - 1/4) - x2*(zeeta/4 + 1/4) + x3*(zeeta/4 + 1/4) - x4*(zeeta/4 - 1/4))^2 + (y1*(zeeta/4 - 1/4) - y2*(zeeta/4 + 1/4) + y3*(zeeta/4 + 1/4) - y4*(zeeta/4 - 1/4))^2)^(1/2) ;
    Fext_traction4=Fext_traction4+(Fext4)*w(i);
end

Fext_traction=vpa((Fext_traction1+Fext_traction2-Fext_traction3-Fext_traction4))*te;
end